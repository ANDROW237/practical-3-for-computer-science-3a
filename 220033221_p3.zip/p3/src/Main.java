import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {	
	
	/**
	 * A method for recursively search for a String in an array of Strings
	 * @param word - The word of type String that we are looking for.
	 * @param words - The String array containing all the words
	 * @param lo - The lower bound for the search
	 * @param hi - The upper bound for the search
	 * @return the index of the found word in the words array
	 * (10 marks) ********************************************
	 */
	public static int recursiveBinarySearch(String word, String[] words, int lo, int hi){		
		//TODO: Complete
		if (lo<=1) {
		int middle= lo+(hi-lo)/2 ;
		
		
		if (words[middle].equals(word)) {
			return middle; // the word was found
		}else if(words[middle].compareTo(word)>0){  // checking the left half side of the code
			return recursiveBinarySearch (word,words,lo,middle-1);
			
		} else {
			return recursiveBinarySearch (word,words,middle+1,hi);//checking the right side of the code
		}
		}
				
		return -1;
	
	}
	
	/**
	 * @param word - The String which its characters will be shuffled around
	 * @return The shuffled String
	 * (5 marks) ********************************************
	 */
	public static String mixCharacterOrder(String word){	
		//TODO: Complete
		
		//breaking the string in a sequence of charaters
		char [] arr= word.toCharArray();
		
		// now need top shuffle the position of all character
		Random rand = new Random(); // function to random 
		
		for (int i = 0; i < arr.length; i++) {
			int randomIndexToSwap = rand.nextInt(arr.length);
			char temp = arr[randomIndexToSwap];
			arr[randomIndexToSwap] = arr[i];
			arr[i] = temp;
		}
		
		// casting into a string
		return new String(arr);
		
		
	}
	/**
	 * The conundrum solver that uses the array dictionary, mixCharacterOrder 
	 * and recursive binary search.
	 * @param conundrum - The current conundrum that needs to be solved.
	 * @param words - The String array containing all the dictionary words
	 * @return A valid word that can be found in the conundrum
	 * (5 marks) ********************************************
	 */
	public static String solveConundrum1(String conundrum, String[] words){				
		//TODO: Complete	
		conundrum =mixCharacterOrder(conundrum);
		Arrays.sort(words);
		int compter = recursiveBinarySearch(conundrum, words, 0, words.length);
		return compter !=-1? words[compter]: "No occurence";
	}
	
	/**
	 * The conundrum solver that uses the DList dictionary, mixCharacterOrder 
	 * and the DList search.
	 * @param conundrum - The current conundrum that needs to be solved.
	 * @param words - The String array containing all the dictionary words
	 * @return A valid word that can be found in the conundrum
	 */
	public static String solveConundrum2(String conundrum, DList<String> words){		
		while(words.search(conundrum) == null){
			conundrum = mixCharacterOrder(conundrum);
		}
		return conundrum;				
	}
	/**
	 * @param path - The location of the dictionary
	 * @return The String array of words  containing all the dictionary words
	 * (5 marks) ********************************************
	 */
	public static String[] loadPotentialDicitonary1(String path){
		//TODO: Complete		
	List <String > strlist= new ArrayList<>();
	String [] array= new String[strlist.size()];
	try {
		File file = new File(path);
		Scanner scan = new Scanner (file);
		while (scan.hasNextLine()) {
			strlist.add(scan.nextLine());
			
		}
		scan.close();
	} catch (FileNotFoundException ex) {
		ex.printStackTrace();
	}
	System.out.println(strlist.size()+"why do we return the size but anyway it has been loaded");
	return strlist.toArray(array);
	}	
	
	/**
	 * @param path - The location of the dictionary
	 * @return The String array of words  containing all the dictionary words
	 */
	public static DList<String> loadPotentialDictionary2(String path){		
		DList<String> wordsList = new DList<String>();
		File f = new File(path);		
		 
		try {
			Scanner s = new Scanner(f);
			
			while(s.hasNextLine()){
				wordsList.addLast(s.nextLine());					
			}			
			s.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}	
		System.out.println(wordsList.size()+ " entries loaded");
		return wordsList;
	}
	/*
	 * The main method
	 * //(10 marks for execution) ********************************************
	 */
	public static void main(String[] args) {
		
		final String PATH = "src/test.dict"; 
		String conundrum = "ionlitabo";
		
		System.out.println("Dictionary Load 1 begin");
		long startTime = System.currentTimeMillis();
		String[] words = loadPotentialDicitonary1(PATH);
		long endTime = System.currentTimeMillis();
		double totalTime = (endTime - startTime)/1000.0;
		System.out.println("Dictionary Load 1 completed in "+ totalTime+" seconds");
		
		System.out.println("Dictionary Load 2 begin");
		startTime = System.currentTimeMillis();
		DList<String> wordList = loadPotentialDictionary2(PATH);
		endTime = System.currentTimeMillis();
		totalTime = (endTime - startTime)/1000.0;
		System.out.println("Dictionary Load 2 completed in "+ totalTime+" seconds");
		
		System.out.println("Algorithm 1 Test begin");
		startTime = System.currentTimeMillis();
		//System.out.println("The found word is: "+solveConundrum1(conundrum, words));
		endTime = System.currentTimeMillis();
		totalTime = (endTime - startTime)/1000.0;
		System.out.println("Algorithm 1 Test completed in "+ totalTime+" seconds");
		
		System.out.println("Algorithm 2 Test begin");
		startTime = System.currentTimeMillis();
		System.out.println("The found word is: "+solveConundrum2(conundrum, wordList));
		endTime = System.currentTimeMillis();
		totalTime = (endTime - startTime)/1000.0;
		System.out.println("Algorithm 2 Test completed in "+ totalTime+" seconds");
		
	//	String name  = mixCharacterOrder("Andrew");
		//System.out.println(name);
	}

}
